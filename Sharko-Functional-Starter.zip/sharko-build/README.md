# Sharko AI — standalone rebrand starter

This package is a newly authored, independent Sharko site using the supplied Sharko logo assets. It is not a copy of the third-party snapshot. It provides public landing pages, Portuguese/English toggling on the landing page, terms/privacy, news, download, transparency, login/register and a guarded `/chat` route placeholder.

## Run in GitHub Codespaces
No npm dependencies are required:
```bash
npm start
```
Open forwarded port 3000.

## Routes
- `/` public landing
- `/login` registration/sign-in
- `/chat` guarded placeholder (not connected to the React chat app)
- `/news`, `/download`, `/transparency`, `/about`, `/developers`, `/terms`, `/privacy`

## Important security and legal notes
Authentication is a prototype using JSON files and Node `scrypt`; it is not production ready. Before deployment, use a managed database, session store, HTTPS, secure cookies, CSRF defenses, throttling, password recovery/email verification, security monitoring, backups, and independent review. The legal text is a draft; fill in controller identity/contact, actual AI vendors, data retention, international transfer details, and have Brazilian counsel review before publication. The chat UI/API is not integrated in this package yet.
